import React, { Component } from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
export default class Pro1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      info: [],
    };
  }
  async componentDidMount() {
    const url =
      "https://cors-anywhere.herokuapp.com/https://jsonkeeper.com/b/356L";
    const response = await fetch(url);
    const datas = await response.json();
    this.setState({ info: datas });
    console.log(this.state.info.data.purchased_services[0]);
  }
  render() {
    return (
      <>
        {this.state.info.data.purchased_services.map((info, index) => {
          <h2>{info[0]["data"]}</h2>;
        })}
        <div className="card" style={{ width: "80rem" }}>
          <div className="card-body">
            <h5 className="card-title">PURCHASED SERVICES</h5>
            <p className="card-text">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
            {/* <h5>{this.state.info[0].name}</h5> */}
            <div className="card">
              <div className="card-body">
                This is some text within a card body.
              </div>
            </div>
            <h5>Main Service 2:</h5>
            <div className="card">
              <div className="card-body">
                This is some text within a card body.
              </div>
            </div>
            <h5>Main Service 3:</h5>
            <div className="card">
              <div className="card-body">
                This is some text within a card body.
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
