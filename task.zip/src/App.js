import React from "react";
import Pro from "./Pro";
import Pro1 from "./Pro1";
const App = () => {
  return (
    <div className="App">
      <Pro1 />
    </div>
  );
};

export default App;
